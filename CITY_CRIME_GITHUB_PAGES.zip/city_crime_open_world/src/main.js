import * as THREE from 'three';
import './style.css';

const $ = (id)=>document.getElementById(id);
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8eb2c4);
scene.fog = new THREE.Fog(0x8eb2c4, 85, 270);
const camera = new THREE.PerspectiveCamera(68, innerWidth/innerHeight, .1, 600);
const renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:'high-performance'});
renderer.setSize(innerWidth,innerHeight); renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));
renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.outputColorSpace=THREE.SRGBColorSpace; renderer.toneMapping=THREE.ACESFilmicToneMapping;
$('game').appendChild(renderer.domElement);

const hemi = new THREE.HemisphereLight(0xc9e4f0,0x4a5145,2.0); scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffe0b0,2.4); sun.position.set(-65,100,35); sun.castShadow=true; sun.shadow.mapSize.set(2048,2048); sun.shadow.camera.left=-110; sun.shadow.camera.right=110; sun.shadow.camera.top=110; sun.shadow.camera.bottom=-110; scene.add(sun);

const mat=(color,roughness=.85)=>new THREE.MeshStandardMaterial({color,roughness});
const mats={road:mat(0x303a40),side:mat(0x8d9692),line:mat(0xe6dfc6),grass:mat(0x647d59),concrete:mat(0x9a9b91),glass: new THREE.MeshStandardMaterial({color:0x436879,metalness:.35,roughness:.25}),white:mat(0xe5e2d9),dark:mat(0x202a30),yellow:mat(0xe9b44c),red:mat(0xb94c3f),green:mat(0x537c60)};
const boxGeo=new THREE.BoxGeometry(1,1,1);
function box(w,h,d,material,x,y,z,shadow=true){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);m.position.set(x,y,z);m.castShadow=shadow;m.receiveShadow=true;scene.add(m);return m}
function ground(w,d,material,x=0,z=0){return box(w,.5,d,material,x,-.28,z,false)}
ground(260,260,mats.grass);
const roads=[];
function road(x,z,w,d){box(w,.08,d,mats.road,x,.02,z,false); roads.push({x,z,w,d}); if(w>d){for(let a=-w/2+4;a<w/2-2;a+=8)box(3,.025,.16,mats.line,x+a,.07,z,false)}else{for(let a=-d/2+4;a<d/2-2;a+=8)box(.16,.025,3,mats.line,x,.07,z+a,false)}}
for(let v=-100;v<=100;v+=40){road(v,0,9,220);road(0,v,220,9)}
// sidewalks
for(let v=-100;v<=100;v+=40){box(3,.22,220,mats.side,v-6,.08,0,false);box(3,.22,220,mats.side,v+6,.08,0,false);box(220,.22,3,mats.side,0,.08,v-6,false);box(220,.22,3,mats.side,0,.08,v+6,false)}
// buildings and lots
const buildings=[];
for(let x=-90;x<=90;x+=20){for(let z=-90;z<=90;z+=20){if(Math.abs(x%40)<1||Math.abs(z%40)<1)continue;const h=8+Math.random()*28,w=8+Math.random()*5,d=8+Math.random()*5;const palette=[0x9c9c91,0x6e7b7d,0xc1b39c,0x777d83,0xb1a18d,0x53636a];const b=box(w,h,d,mat(palette[Math.floor(Math.random()*palette.length)]),x,h/2,z);buildings.push(b);for(let y=3;y<h-2;y+=4){for(let side of [-1,1]){const win=box(1.3,1.1,.08,mats.glass,x-w/2-.045,y,z+side*d/2);win.castShadow=false;}}if(Math.random()>.6){box(w*.35,.6,d*.35,mats.dark,x,h+.3,z,false)}}}
// beach / water edge
const water=new THREE.Mesh(new THREE.PlaneGeometry(90,260),new THREE.MeshStandardMaterial({color:0x2c7890,roughness:.22,metalness:.15}));water.rotation.x=-Math.PI/2;water.position.set(170,-.2,0);scene.add(water);
for(let i=0;i<35;i++){let x=-115+Math.random()*230,z=-115+Math.random()*230;if(Math.abs(x%40)<8||Math.abs(z%40)<8)continue;const trunk= new THREE.Mesh(new THREE.CylinderGeometry(.25,.38,3,7),mat(0x60432c));trunk.position.set(x,1.5,z);trunk.castShadow=true;scene.add(trunk);const crown=new THREE.Mesh(new THREE.SphereGeometry(2.1,7,6),mat(0x3e6949));crown.position.set(x,3.8,z);crown.castShadow=true;scene.add(crown)}
// lamps
for(let v=-100;v<=100;v+=20){for(const axis of [0,1]){let x=axis?v:6,z=axis?6:v;box(.18,5,.18,mats.dark,x,2.5,z);box(1,.12,.35,mats.yellow,x+.35,5,z)}}
// player
const player=new THREE.Group();scene.add(player);
const body=new THREE.Mesh(new THREE.CapsuleGeometry(.48,.9,4,8),mat(0x344c59));body.position.y=1.15;body.castShadow=true;player.add(body);
const head=new THREE.Mesh(new THREE.SphereGeometry(.3,12,10),mat(0xc18d6d));head.position.y=2;head.castShadow=true;player.add(head);
const legs=new THREE.Group();player.add(legs);
player.position.set(-7,0,-7);
let yaw=0, pitch=-.12, velocity=new THREE.Vector3(), health=100, armor=25, cash=2500, wanted=0, inCar=null, dead=false, started=false, paused=true;
const keys={};let lastToast=0;
function toast(msg){$('toast').textContent=msg;$('toast').classList.add('show');clearTimeout(lastToast);lastToast=setTimeout(()=>$('toast').classList.remove('show'),2200)}
// vehicles
const cars=[];
function makeCar(x,z,color=0x3c7890,type='sedan'){const g=new THREE.Group();const base=new THREE.Mesh(new THREE.BoxGeometry(type==='truck'?2.6:1.9,.65,type==='truck'?5.1:3.8),mat(color,.5));base.position.y=.75;base.castShadow=true;g.add(base);const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.55,.8,1.8),mats.glass);cabin.position.set(0,1.42,-.2);g.add(cabin);for(let wx of [-.9,.9])for(let wz of [-1.25,1.25]){const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.38,.38,.22,12),mats.dark);wheel.rotation.z=Math.PI/2;wheel.position.set(wx,.4,wz);g.add(wheel)}g.position.set(x,0,z);scene.add(g);const car={g,speed:0,yaw:0,color,type,hp:100,owned:false};cars.push(car);return car}
makeCar(-10,0,0x2e7187);makeCar(8,0,0xb5a15e);makeCar(0,10,0x9d4b40);makeCar(42,-38,0x526c5c);makeCar(-45,40,0x444c65);makeCar(78,2,0xc5c2b6,'truck');
const traffic=[];
for(let i=0;i<12;i++){const c=makeCar(-100+Math.random()*200, -100+Math.random()*200,[0x9c5546,0x49718a,0xb6aa8d,0x555d60][i%4]);traffic.push(c);c.ai=true;c.speed=3+Math.random()*2;c.yaw=Math.random()*Math.PI*2;c.g.rotation.y=c.yaw}
// NPCs
const npcs=[];
function makeNPC(x,z,hostile=false,police=false){const g=new THREE.Group();const shirt=mat(police?0x263e59:(hostile?0x713f35:[0x777b69,0x465b69,0x947e62,0x6b536a][Math.floor(Math.random()*4)]));const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.35,.65,3,7),shirt);torso.position.y=1;g.add(torso);const h=new THREE.Mesh(new THREE.SphereGeometry(.23,10,8),mat(0xb98b6b));h.position.y=1.75;g.add(h);g.position.set(x,0,z);scene.add(g);const n={g,hp:100,hostile,police,dir:Math.random()*6.28,alert:false};npcs.push(n);return n}
for(let i=0;i<28;i++){let x=-90+Math.random()*180,z=-90+Math.random()*180;makeNPC(x,z)}
// mission markers
const marker=new THREE.Mesh(new THREE.CylinderGeometry(1.1,1.1,.12,24),new THREE.MeshBasicMaterial({color:0xf0bd53}));marker.position.set(42,.1,-38);scene.add(marker);
const missionTargets=[{x:42,z:-38,title:'Первое дело',desc:'Доберись до отмеченного автомобиля.',reward:500},{x:-48,z:42,title:'Доставка',desc:'Доставь автомобиль к промышленному кварталу.',reward:850},{x:78,z:2,title:'Городской маршрут',desc:'Найди грузовик на востоке города.',reward:1200}];let missionIndex=0, missionDone=false;
function setMission(){const m=missionTargets[missionIndex%missionTargets.length];marker.position.set(m.x,.1,m.z);$('mission-title').textContent=m.title;$('mission-desc').textContent=m.desc}
setMission();
// police
let policeUnits=[], wantedTimer=0, lastKnown=new THREE.Vector3();
function addWanted(n=1){wanted=Math.min(5,Math.max(wanted,n));wantedTimer=0;lastKnown.copy(player.position);$('wanted').textContent='★'.repeat(wanted)+'☆'.repeat(5-wanted);if(!policeUnits.length){for(let i=0;i<Math.min(wanted+1,4);i++){let p=makeNPC(player.position.x+25+Math.random()*15,player.position.z+25, false,true);p.speed=0;policeUnits.push(p)}}toast('Внимание! Уровень розыска повышен');}
function clearWanted(){wanted=0;policeUnits.forEach(p=>scene.remove(p.g));policeUnits=[];$('wanted').textContent='☆☆☆☆☆';toast('Полиция потеряла твой след');}
function damage(amount){if(armor>0){let a=Math.min(armor,amount*.55);armor-=a;amount-=a}health=Math.max(0,health-amount);if(health<=0){dead=true;paused=true;$('death-screen').classList.remove('hidden');document.exitPointerLock?.()}}
function respawn(){health=100;armor=25;dead=false;player.position.set(-7,0,-7);velocity.set(0,0,0);clearWanted();$('death-screen').classList.add('hidden');paused=false;renderer.domElement.requestPointerLock?.()}
// input
addEventListener('keydown',e=>{keys[e.code]=true;if(e.code==='Escape'&&started&&!dead){paused=!paused;$('pause-screen').classList.toggle('hidden',!paused);if(paused)document.exitPointerLock?.();else renderer.domElement.requestPointerLock?.()}if(e.code==='KeyM'&&started&&!paused){$('map-screen').classList.remove('hidden');paused=true;drawMap($('bigmap'),true);document.exitPointerLock?.()}if(e.code==='KeyF'&&started&&!paused)toggleCar();if(e.code==='KeyE'&&started&&!paused)interact();if(e.code==='Digit1')toast('Выбраны кулаки');});
addEventListener('keyup',e=>keys[e.code]=false);
renderer.domElement.addEventListener('click',()=>{if(started&&!paused&&!dead&&$('map-screen').classList.contains('hidden'))renderer.domElement.requestPointerLock?.()});
addEventListener('mousemove',e=>{if(document.pointerLockElement===renderer.domElement&&!paused){yaw-=e.movementX*.0022;pitch=Math.max(-.75,Math.min(.3,pitch-e.movementY*.0018))}});
addEventListener('mousedown',e=>{if(e.button===0&&started&&!paused&&!dead&&document.pointerLockElement===renderer.domElement)attack()});
function nearestCar(){let best=null,dist=5;for(const c of cars){let d=c.g.position.distanceTo(player.position);if(d<dist){best=c;dist=d}}return best}
function toggleCar(){if(inCar){player.position.copy(inCar.g.position).add(new THREE.Vector3(2,0,0));inCar=null;toast('Ты вышел из автомобиля');return}const c=nearestCar();if(c){inCar=c;toast('Автомобиль захвачен');if(!c.owned)addWanted(1)}}
function interact(){const c=nearestCar();if(c){toggleCar();return}toast('Поблизости нет доступных объектов')}
function attack(){if(inCar)return;let target=null,dist=3.2;for(const n of npcs){let d=n.g.position.distanceTo(player.position);if(d<dist){target=n;dist=d}}if(target){target.hp-=45;target.alert=true;addWanted(1);toast('Попадание');if(target.hp<=0){scene.remove(target.g);npcs.splice(npcs.indexOf(target),1);cash+=80;updateHUD()}}else{toast('Удар')}
}
function updateHUD(){$('cash').textContent='$ '+cash.toLocaleString('en-US');$('health-value').textContent=Math.round(health);$('armor-value').textContent=Math.round(armor);$('health-bar').style.width=health+'%';$('armor-bar').style.width=armor+'%'}
function drawMap(canvas,big=false){const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);ctx.fillStyle='#243b3c';ctx.fillRect(0,0,w,h);const scale=big?2.7:.68,cx=player.position.x,cz=player.position.z;ctx.save();ctx.translate(w/2,h/2);ctx.scale(scale,scale);ctx.translate(-cx,-cz);ctx.fillStyle='#4a5557';roads.forEach(r=>ctx.fillRect(r.x-r.w/2,r.z-r.d/2,r.w,r.d));ctx.strokeStyle='#a6aaa0';ctx.lineWidth=big?1.2:.6;roads.forEach(r=>{ctx.strokeRect(r.x-r.w/2,r.z-r.d/2,r.w,r.d)});ctx.fillStyle='#788878';buildings.forEach(b=>ctx.fillRect(b.position.x-4,b.position.z-4,8,8));ctx.fillStyle='#e9b44c';ctx.beginPath();ctx.arc(missionTargets[missionIndex%missionTargets.length].x,missionTargets[missionIndex%missionTargets.length].z,2.5,0,Math.PI*2);ctx.fill();ctx.fillStyle='#6fc8ed';ctx.beginPath();ctx.arc(player.position.x,player.position.z,2.7,0,Math.PI*2);ctx.fill();ctx.restore()}
function updateMission(){const m=missionTargets[missionIndex%missionTargets.length];if(player.position.distanceTo(new THREE.Vector3(m.x,0,m.z))<6){cash+=m.reward;missionIndex++;setMission();updateHUD();toast('Задание выполнено! +$'+m.reward)}}
function update(dt){if(paused||dead)return;const forward=new THREE.Vector3(Math.sin(yaw),0,Math.cos(yaw));const right=new THREE.Vector3(forward.z,0,-forward.x);
 if(inCar){let accel=(keys.KeyW?1:0)-(keys.KeyS?1:0);inCar.speed+=accel*dt*16;inCar.speed*=Math.pow(.985,dt*60);inCar.speed=THREE.MathUtils.clamp(inCar.speed,-9,25);inCar.yaw+=(keys.KeyA?1:0)-(keys.KeyD?1:0);inCar.yaw*=1;inCar.g.rotation.y=inCar.yaw;const dir=new THREE.Vector3(Math.sin(inCar.yaw),0,Math.cos(inCar.yaw));inCar.g.position.addScaledVector(dir,inCar.speed*dt);inCar.g.position.x=THREE.MathUtils.clamp(inCar.g.position.x,-118,118);inCar.g.position.z=THREE.MathUtils.clamp(inCar.g.position.z,-118,118);player.position.copy(inCar.g.position);player.position.y=0; if(keys.Space)inCar.speed*=.92;
 }else{let move=new THREE.Vector3();if(keys.KeyW)move.add(forward);if(keys.KeyS)move.sub(forward);if(keys.KeyD)move.add(right);if(keys.KeyA)move.sub(right);if(move.lengthSq())move.normalize();const speed=keys.ShiftLeft?10:5.5;velocity.x=THREE.MathUtils.lerp(velocity.x,move.x*speed,.14);velocity.z=THREE.MathUtils.lerp(velocity.z,move.z*speed,.14);player.position.addScaledVector(velocity,dt);player.rotation.y=yaw;if(keys.Space&&player.position.y<.05)velocity.y=5;velocity.y-=15*dt;player.position.y=Math.max(0,player.position.y+velocity.y*dt);if(player.position.y===0)velocity.y=0;player.position.x=THREE.MathUtils.clamp(player.position.x,-122,122);player.position.z=THREE.MathUtils.clamp(player.position.z,-122,122)}
 // basic traffic movement
 traffic.forEach(c=>{c.g.position.add(new THREE.Vector3(Math.sin(c.yaw),0,Math.cos(c.yaw)).multiplyScalar(c.speed*dt));if(Math.abs(c.g.position.x)>110||Math.abs(c.g.position.z)>110)c.yaw+=Math.PI;c.g.rotation.y=c.yaw});
 // NPC wandering and hostile response
 npcs.forEach(n=>{if(n.police){const target=lastKnown;const d=n.g.position.distanceTo(player.position);if(wanted){const dir=player.position.clone().sub(n.g.position).setY(0).normalize();n.g.position.addScaledVector(dir,dt*(wanted>2?5:3));n.g.lookAt(player.position.x,0,player.position.z);if(d<3&&Math.random()<dt*.5)damage(7)}return}if(n.alert){const dir=n.g.position.clone().sub(player.position).setY(0).normalize();n.g.position.addScaledVector(dir,dt*2.5)}else{n.dir+= (Math.random()-.5)*dt*.7;n.g.position.x+=Math.sin(n.dir)*dt*.7;n.g.position.z+=Math.cos(n.dir)*dt*.7}});
 if(wanted){wantedTimer+=dt;if(player.position.distanceTo(lastKnown)>32)wantedTimer+=dt*1.5;if(wantedTimer>28){wanted--;wantedTimer=0;$('wanted').textContent='★'.repeat(wanted)+'☆'.repeat(5-wanted);if(wanted===0)clearWanted()}}
 updateMission();updateHUD();$('vehicle-hint').classList.toggle('show',!inCar&&!!nearestCar());
 const targetPos=inCar?inCar.g.position:player.position;const camDir=new THREE.Vector3(Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),Math.cos(yaw)*Math.cos(pitch));const desired=targetPos.clone().add(new THREE.Vector3(0,inCar?4:3.1,0)).addScaledVector(camDir,-(inCar?9:7));camera.position.lerp(desired,.13);camera.lookAt(targetPos.x,targetPos.y+(inCar?1.2:1.45),targetPos.z);
}
let worldTime=12;
function animate(){requestAnimationFrame(animate);const dt=Math.min(clockDelta.getDelta(),.04);if(started){update(dt);worldTime=(worldTime+dt*.12)%24;const hour=Math.floor(worldTime),mins=Math.floor((worldTime%1)*60);$('clock').textContent=String(hour).padStart(2,'0')+':'+String(mins).padStart(2,'0');const night=hour<6||hour>19;const sky=night?new THREE.Color(0x101b30):new THREE.Color(0x8eb2c4);scene.background.lerp(sky,.004);scene.fog.color.copy(scene.background);sun.intensity=night?.35:2.4;hemi.intensity=night?.45:2.0;drawMap($('minimap'))}renderer.render(scene,camera)}
const clockDelta=new THREE.Clock();animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.7))});
// UI
$('start').onclick=()=>{started=true;paused=false;$('start-screen').classList.add('hidden');renderer.domElement.requestPointerLock?.();toast('Добро пожаловать в город')};
$('resume').onclick=()=>{paused=false;$('pause-screen').classList.add('hidden');renderer.domElement.requestPointerLock?.()};
$('save').onclick=()=>{const data={player:player.position.toArray(),cash,health,armor,missionIndex,worldTime};localStorage.setItem('cityCrimeSave',JSON.stringify(data));toast('Игра сохранена')};
$('new-game').onclick=()=>{localStorage.removeItem('cityCrimeSave');location.reload()};
$('respawn').onclick=respawn;
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>{$('map-screen').classList.add('hidden');paused=false;renderer.domElement.requestPointerLock?.()});
try{const s=JSON.parse(localStorage.getItem('cityCrimeSave'));if(s){player.position.fromArray(s.player||[-7,0,-7]);cash=s.cash??2500;health=s.health??100;armor=s.armor??25;missionIndex=s.missionIndex??0;worldTime=s.worldTime??12;setMission();updateHUD();$('start').textContent='ПРОДОЛЖИТЬ ИГРУ →'}}catch{}
updateHUD();
